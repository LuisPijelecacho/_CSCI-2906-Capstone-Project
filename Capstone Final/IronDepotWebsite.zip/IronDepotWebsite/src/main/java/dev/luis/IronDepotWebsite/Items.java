package dev.luis.IronDepotWebsite;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document (collection = "items")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Items {
    @Id
    private ObjectId id;
    private String name;
    private String brand;
    private String sku;
    private String description;
    private List <String> features;
    private String image;
    private double price;



}

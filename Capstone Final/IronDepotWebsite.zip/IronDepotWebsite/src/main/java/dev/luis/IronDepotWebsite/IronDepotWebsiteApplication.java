package dev.luis.IronDepotWebsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IronDepotWebsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(IronDepotWebsiteApplication.class, args);
	}


}

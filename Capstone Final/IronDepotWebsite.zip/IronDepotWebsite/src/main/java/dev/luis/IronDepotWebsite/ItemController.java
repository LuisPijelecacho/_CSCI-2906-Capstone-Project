package dev.luis.IronDepotWebsite;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1")

@CrossOrigin("http://localhost:3000")
public class ItemController {

    @Autowired
    private ItemService itemService;

    @GetMapping("/")
    public ResponseEntity<List<HomePage>> getAllHomeImages() {
        return new ResponseEntity<>(itemService.getHomePageImages(), HttpStatus.OK);
    }


    @GetMapping("/items")
    public ResponseEntity<List<Items>> getAllItems() {
        return new ResponseEntity<>(itemService.allItems(), HttpStatus.OK);
    }

    @GetMapping("/{sku}")
    public ResponseEntity<Optional<Items>> getSingleItem(@PathVariable Integer sku) {
        return new ResponseEntity<>(itemService.singleItem(sku), HttpStatus.OK);
    }
}

package dev.luis.IronDepotWebsite;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ItemService {
    @Autowired
    private ItemRepository itemRepository;

    @Autowired
    private HomePageRepository homePageRepository;

    public List<HomePage> getHomePageImages() {
        return homePageRepository.findAll();
    }

    public List<Items> allItems(){
        return itemRepository.findAll();
    }

    public Optional<Items> singleItem(Integer sku){
        return itemRepository.findBySku(sku);
    }
}

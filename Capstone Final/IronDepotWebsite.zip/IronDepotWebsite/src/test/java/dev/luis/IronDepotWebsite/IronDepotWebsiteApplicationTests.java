package dev.luis.IronDepotWebsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IronDepotWebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
